# Portfolio Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/Sivakumar-S-the-looper/pen/pvzaowG](https://codepen.io/Sivakumar-S-the-looper/pen/pvzaowG).

After 7 months of programming everyday and more than 30 projects built, this is last project I made for the FreeCodeCamp curriculum. 

It's been a great journey and I learnt A LOT of new stuff!